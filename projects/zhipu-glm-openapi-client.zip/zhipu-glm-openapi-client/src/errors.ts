import type { ApiErrorPayload } from './types.js';

export class ZhipuApiError extends Error {
  readonly name = 'ZhipuApiError';
  readonly status: number;
  readonly statusText: string;
  readonly url: string;
  readonly payload: ApiErrorPayload | string | undefined;

  constructor(args: {
    status: number;
    statusText: string;
    url: string;
    payload?: ApiErrorPayload | string | undefined;
  }) {
    const detail = typeof args.payload === 'string'
      ? args.payload
      : args.payload?.message ?? JSON.stringify(args.payload ?? {});
    super(`Zhipu API request failed: ${args.status} ${args.statusText}${detail ? ` - ${detail}` : ''}`);
    this.status = args.status;
    this.statusText = args.statusText;
    this.url = args.url;
    this.payload = args.payload;
  }
}
