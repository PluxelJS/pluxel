/** Placeholder overwritten by `npm run refresh`. */
export { client } from './client.gen.js';
