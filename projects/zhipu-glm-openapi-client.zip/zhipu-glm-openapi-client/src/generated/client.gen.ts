/** Placeholder overwritten by `npm run refresh`. */
export const client = {
  setConfig(_config: unknown): void {
    // no-op placeholder
  },
};
