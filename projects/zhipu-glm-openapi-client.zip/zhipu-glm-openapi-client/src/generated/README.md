# Generated client output

Run:

```bash
npm run refresh
```

The generated Hey API fetch client will be written here.

Typical usage after generation:

```ts
import { client } from './src/generated/client.gen';

client.setConfig({
  baseUrl: 'https://open.bigmodel.cn/api/paas/v4',
  headers: { Authorization: `Bearer ${process.env.ZHIPU_API_KEY}` },
});
```

Operation helper names depend on the official OpenAPI `operationId` values.
