export type PrimitiveQueryValue = string | number | boolean | null | undefined;

export type QueryValue =
  | PrimitiveQueryValue
  | readonly PrimitiveQueryValue[];

export type QueryParams = Record<string, QueryValue>;

export type JsonValue =
  | string
  | number
  | boolean
  | null
  | { [key: string]: JsonValue }
  | JsonValue[];

export type RequestBody =
  | JsonValue
  | FormData
  | URLSearchParams
  | Blob
  | ArrayBuffer
  | ArrayBufferView
  | ReadableStream<Uint8Array>
  | string
  | null
  | undefined;

export type ResponseType =
  | 'json'
  | 'text'
  | 'blob'
  | 'arrayBuffer'
  | 'stream'
  | 'void';

export interface ZhipuClientOptions {
  /** Defaults to process.env.ZHIPU_API_KEY when available. */
  apiKey?: string;
  /** Defaults to https://open.bigmodel.cn/api/paas/v4. */
  baseUrl?: string;
  /** Optional custom fetch implementation, useful for tests, proxying, or edge runtimes. */
  fetch?: typeof fetch;
  /** Headers attached to every request. Authorization is added automatically from apiKey. */
  headers?: HeadersInit;
}

export interface RequestOptions<B extends RequestBody = RequestBody> {
  method: string;
  path: string;
  query?: QueryParams;
  body?: B;
  headers?: HeadersInit;
  signal?: AbortSignal;
  responseType?: ResponseType;
}

export interface ApiErrorPayload {
  error?: unknown;
  message?: string;
  [key: string]: unknown;
}
