import { ZhipuApiError } from './errors.js';
import type {
  ApiErrorPayload,
  QueryParams,
  RequestBody,
  RequestOptions,
  ResponseType,
  ZhipuClientOptions,
} from './types.js';

const DEFAULT_BASE_URL = 'https://open.bigmodel.cn/api/paas/v4';

function readEnv(name: string): string | undefined {
  // Browser-safe access to Node-style env variables.
  const maybeProcess = globalThis as unknown as {
    process?: { env?: Record<string, string | undefined> };
  };
  return maybeProcess.process?.env?.[name];
}

function trimSlashes(input: string, side: 'left' | 'right' | 'both' = 'both'): string {
  if (side === 'left') return input.replace(/^\/+/, '');
  if (side === 'right') return input.replace(/\/+$/, '');
  return input.replace(/^\/+|\/+$/g, '');
}

function appendQuery(url: URL, query?: QueryParams): void {
  if (!query) return;
  for (const [key, value] of Object.entries(query)) {
    if (value === undefined || value === null) continue;
    if (Array.isArray(value)) {
      for (const item of value) {
        if (item !== undefined && item !== null) url.searchParams.append(key, String(item));
      }
      continue;
    }
    url.searchParams.set(key, String(value));
  }
}

function isJsonLikeBody(body: RequestBody): body is Exclude<RequestBody, FormData | URLSearchParams | Blob | ArrayBuffer | ArrayBufferView | ReadableStream<Uint8Array> | string | null | undefined> {
  if (body === null || body === undefined) return false;
  if (typeof body === 'string') return false;
  if (typeof FormData !== 'undefined' && body instanceof FormData) return false;
  if (typeof URLSearchParams !== 'undefined' && body instanceof URLSearchParams) return false;
  if (typeof Blob !== 'undefined' && body instanceof Blob) return false;
  if (body instanceof ArrayBuffer) return false;
  if (ArrayBuffer.isView(body)) return false;
  if (typeof ReadableStream !== 'undefined' && body instanceof ReadableStream) return false;
  return true;
}

async function parseErrorPayload(response: Response): Promise<ApiErrorPayload | string | undefined> {
  const contentType = response.headers.get('content-type') ?? '';
  try {
    if (contentType.includes('application/json')) return await response.json() as ApiErrorPayload;
    const text = await response.text();
    return text || undefined;
  } catch {
    return undefined;
  }
}

async function parseSuccess<T>(response: Response, responseType: ResponseType): Promise<T> {
  if (response.status === 204 || responseType === 'void') return undefined as T;
  if (responseType === 'stream') return response.body as T;
  if (responseType === 'text') return await response.text() as T;
  if (responseType === 'blob') return await response.blob() as T;
  if (responseType === 'arrayBuffer') return await response.arrayBuffer() as T;

  const contentType = response.headers.get('content-type') ?? '';
  if (!contentType.includes('application/json')) {
    return await response.text() as T;
  }
  return await response.json() as T;
}

export class ZhipuClient {
  readonly baseUrl: string;
  private readonly apiKey: string | undefined;
  private readonly fetchImpl: typeof fetch;
  private readonly defaultHeaders: HeadersInit;

  constructor(options: ZhipuClientOptions = {}) {
    this.baseUrl = trimSlashes(options.baseUrl ?? readEnv('ZHIPU_BASE_URL') ?? DEFAULT_BASE_URL, 'right');
    this.apiKey = options.apiKey ?? readEnv('ZHIPU_API_KEY');
    this.fetchImpl = options.fetch ?? globalThis.fetch;
    this.defaultHeaders = options.headers ?? {};

    if (!this.fetchImpl) {
      throw new Error('No fetch implementation found. Use Node.js >=18 or pass options.fetch.');
    }
  }

  url(path: string, query?: QueryParams): URL {
    const normalizedPath = trimSlashes(path, 'left');
    const url = new URL(`${this.baseUrl}/${normalizedPath}`);
    appendQuery(url, query);
    return url;
  }

  async request<T = unknown, B extends RequestBody = RequestBody>(options: RequestOptions<B>): Promise<T> {
    const url = this.url(options.path, options.query);
    const headers = new Headers(this.defaultHeaders);

    if (this.apiKey && !headers.has('authorization')) {
      headers.set('authorization', `Bearer ${this.apiKey}`);
    }

    for (const [key, value] of new Headers(options.headers ?? {})) {
      headers.set(key, value);
    }

    let body: BodyInit | null | undefined;
    if (isJsonLikeBody(options.body)) {
      if (!headers.has('content-type')) headers.set('content-type', 'application/json');
      body = JSON.stringify(options.body);
    } else {
      body = options.body as BodyInit | null | undefined;
    }

    const init: RequestInit = {
      method: options.method.toUpperCase(),
      headers,
    };
    if (body !== undefined) init.body = body;
    if (options.signal !== undefined) init.signal = options.signal;

    const response = await this.fetchImpl(url, init);

    if (!response.ok) {
      throw new ZhipuApiError({
        status: response.status,
        statusText: response.statusText,
        url: url.toString(),
        payload: await parseErrorPayload(response),
      });
    }

    return await parseSuccess<T>(response, options.responseType ?? 'json');
  }

  get<T = unknown>(path: string, options: Omit<RequestOptions<undefined>, 'method' | 'path' | 'body'> = {}): Promise<T> {
    return this.request<T>({ ...options, method: 'GET', path });
  }

  post<T = unknown, B extends RequestBody = RequestBody>(path: string, body?: B, options: Omit<RequestOptions<B>, 'method' | 'path' | 'body'> = {}): Promise<T> {
    const requestOptions: RequestOptions<B> = { ...options, method: 'POST', path };
    if (body !== undefined) requestOptions.body = body;
    return this.request<T, B>(requestOptions);
  }

  put<T = unknown, B extends RequestBody = RequestBody>(path: string, body?: B, options: Omit<RequestOptions<B>, 'method' | 'path' | 'body'> = {}): Promise<T> {
    const requestOptions: RequestOptions<B> = { ...options, method: 'PUT', path };
    if (body !== undefined) requestOptions.body = body;
    return this.request<T, B>(requestOptions);
  }

  delete<T = unknown>(path: string, options: Omit<RequestOptions<undefined>, 'method' | 'path' | 'body'> = {}): Promise<T> {
    return this.request<T>({ ...options, method: 'DELETE', path });
  }

  /** Stable convenience helper for the documented OpenAI-compatible chat endpoint. */
  chatCompletions<T = unknown, B extends RequestBody = RequestBody>(body: B, options: Omit<RequestOptions<B>, 'method' | 'path' | 'body'> = {}): Promise<T> {
    return this.post<T, B>('/chat/completions', body, options);
  }
}

export function createZhipuClient(options?: ZhipuClientOptions): ZhipuClient {
  return new ZhipuClient(options);
}
