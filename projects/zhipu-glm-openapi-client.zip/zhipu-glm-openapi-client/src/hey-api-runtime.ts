const DEFAULT_BASE_URL = 'https://open.bigmodel.cn/api/paas/v4';

function readEnv(name: string): string | undefined {
  const maybeProcess = globalThis as unknown as {
    process?: { env?: Record<string, string | undefined> };
  };
  return maybeProcess.process?.env?.[name];
}

/**
 * Runtime configuration consumed by @hey-api/client-fetch generated code.
 * This file intentionally avoids importing generated types so the project can
 * be checked before `npm run refresh` has produced ./src/generated.
 */
export const createClientConfig = (config: Record<string, unknown> = {}) => {
  const apiKey = readEnv('ZHIPU_API_KEY');
  const baseUrl = readEnv('ZHIPU_BASE_URL') ?? DEFAULT_BASE_URL;

  return {
    ...config,
    baseUrl,
    headers: {
      ...((config.headers as Record<string, string> | undefined) ?? {}),
      ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}),
    },
  };
};
