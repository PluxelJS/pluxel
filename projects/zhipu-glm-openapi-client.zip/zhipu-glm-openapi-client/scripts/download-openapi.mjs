import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const openapiUrl = process.env.ZHIPU_OPENAPI_URL ?? 'https://docs.bigmodel.cn/openapi/openapi.json';
const asyncapiUrl = process.env.ZHIPU_ASYNCAPI_URL ?? 'https://docs.bigmodel.cn/asyncapi/asyncapi.json';

async function fetchJson(url, outputPath) {
  const res = await fetch(url, {
    headers: {
      accept: 'application/json, text/plain;q=0.9, */*;q=0.8',
      'user-agent': 'zhipu-glm-openapi-client-generator/0.1.0',
    },
  });

  if (!res.ok) {
    throw new Error(`GET ${url} failed: ${res.status} ${res.statusText}`);
  }

  const text = await res.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch (error) {
    throw new Error(`GET ${url} did not return valid JSON: ${error.message}`);
  }

  await mkdir(dirname(outputPath), { recursive: true });
  await writeFile(outputPath, `${JSON.stringify(json, null, 2)}\n`);
  return {
    url,
    outputPath,
    bytes: Buffer.byteLength(text),
    title: json?.info?.title,
    version: json?.info?.version,
    specVersion: json?.openapi ?? json?.asyncapi,
    pathCount: json?.paths ? Object.keys(json.paths).length : undefined,
  };
}

const outputs = [];
outputs.push(await fetchJson(openapiUrl, resolve(root, 'openapi/zhipu-openapi.json')));
outputs.push(await fetchJson(asyncapiUrl, resolve(root, 'openapi/zhipu-asyncapi.json')));

await writeFile(
  resolve(root, 'openapi/download-metadata.json'),
  `${JSON.stringify({ downloadedAt: new Date().toISOString(), outputs }, null, 2)}\n`,
);

console.log('Downloaded specs:');
for (const item of outputs) {
  console.log(`- ${item.outputPath} (${item.specVersion ?? 'unknown spec'}, ${item.pathCount ?? 'n/a'} paths)`);
}
