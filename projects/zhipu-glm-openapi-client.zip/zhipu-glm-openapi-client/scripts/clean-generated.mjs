import { rm, mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const dir = resolve(root, 'src/generated');
await rm(dir, { recursive: true, force: true });
await mkdir(dir, { recursive: true });
await writeFile(resolve(dir, 'README.md'), '# Generated client output\n\nRun `npm run refresh`.\n');
console.log('Cleaned src/generated');
