import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const nodeCmd = process.execPath;

for (const script of ['scripts/download-openapi.mjs', 'scripts/generate.mjs']) {
  const result = spawnSync(nodeCmd, [script], {
    cwd: root,
    stdio: 'inherit',
    env: process.env,
  });
  if (result.status !== 0) process.exit(result.status ?? 1);
}
