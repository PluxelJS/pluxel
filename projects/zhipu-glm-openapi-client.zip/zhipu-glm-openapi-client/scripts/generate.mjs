import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

const root = resolve(import.meta.dirname, '..');
const specPath = resolve(root, 'openapi/zhipu-openapi.json');

if (!existsSync(specPath)) {
  console.error('Missing ./openapi/zhipu-openapi.json. Run `npm run download:openapi` first, or run `npm run refresh`.');
  process.exit(1);
}

const npmCmd = process.platform === 'win32' ? 'npx.cmd' : 'npx';
const result = spawnSync(npmCmd, ['@hey-api/openapi-ts', '-c', 'openapi-ts.config.ts'], {
  cwd: root,
  stdio: 'inherit',
  env: process.env,
});

if (result.status !== 0) {
  process.exit(result.status ?? 1);
}
