# zhipu-glm-openapi-client

Fetch-first TypeScript client scaffold for 智谱 / GLM, designed to generate a complete typed SDK from the official OpenAPI spec.

## Choice

I picked `@hey-api/openapi-ts` + `@hey-api/client-fetch` because it is actively maintained, fetch-native, TypeScript-first, and generates production SDK artifacts from OpenAPI specs. It also keeps the runtime thin and works cleanly in Node, browser, edge, and sandbox environments.

## What is included

- `scripts/download-openapi.mjs` — downloads official Zhipu OpenAPI and AsyncAPI specs.
- `openapi-ts.config.ts` — Hey API config for a fetch-based generated client.
- `src/hey-api-runtime.ts` — runtime config for generated clients, using `ZHIPU_API_KEY` and `ZHIPU_BASE_URL`.
- `src/client.ts` — a small hand-written fetch client that works immediately for raw requests and the documented chat endpoint.
- `examples/raw-chat.ts` — immediate fetch-client usage.
- `examples/generated-client.ts` — generated-client setup after running `npm run refresh`.

## Official spec sources

Recorded in `openapi/spec-sources.json`:

- `https://docs.bigmodel.cn/openapi/openapi.json`
- `https://docs.bigmodel.cn/openapi/openapi-en.json`
- `https://docs.bigmodel.cn/asyncapi/asyncapi.json`
- `https://docs.bigmodel.cn/asyncapi/asyncapi-en.json`

## Quick start

```bash
npm install
cp .env.example .env
# edit .env and fill ZHIPU_API_KEY
npm run refresh
```

This will:

1. download the official OpenAPI snapshot to `openapi/zhipu-openapi.json`;
2. download the official AsyncAPI snapshot to `openapi/zhipu-asyncapi.json`;
3. generate the typed fetch SDK under `src/generated`.

## Use the immediate raw client

```ts
import { createZhipuClient } from './src/index.js';

const zhipu = createZhipuClient({
  apiKey: process.env.ZHIPU_API_KEY,
});

const res = await zhipu.chatCompletions({
  model: 'glm-5.2',
  messages: [{ role: 'user', content: '你好' }],
});
```

For any endpoint from the official OpenAPI spec, you can also call raw paths:

```ts
const res = await zhipu.post('/chat/completions', {
  model: 'glm-5.2',
  messages: [{ role: 'user', content: '你好' }],
});
```

## Use the generated client

After `npm run refresh`, inspect `src/generated` for operation helper names generated from the official `operationId` values.

```ts
import { client } from './src/generated/client.gen.js';

client.setConfig({
  baseUrl: 'https://open.bigmodel.cn/api/paas/v4',
  headers: { Authorization: `Bearer ${process.env.ZHIPU_API_KEY}` },
});
```

Then import operation helpers from `src/generated`.

## Notes

- The normal Zhipu API base URL is `https://open.bigmodel.cn/api/paas/v4`.
- Authentication is `Authorization: Bearer YOUR_API_KEY`.
- If you use the Coding endpoint, set `ZHIPU_BASE_URL=https://open.bigmodel.cn/api/coding/paas/v4`.
- Keep generated files committed if you want fully offline builds in CI.
