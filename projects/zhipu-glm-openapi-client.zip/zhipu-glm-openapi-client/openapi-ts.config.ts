/**
 * Hey API generator config.
 *
 * Run:
 *   npm install
 *   npm run refresh
 *
 * This downloads the official Zhipu OpenAPI JSON into ./openapi and generates
 * a fetch-based typed SDK into ./src/generated.
 */
export default {
  input: './openapi/zhipu-openapi.json',
  output: './src/generated',
  plugins: [
    {
      name: '@hey-api/client-fetch',
      runtimeConfigPath: './src/hey-api-runtime.ts',
    },
  ],
};
