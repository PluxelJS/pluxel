# OpenAPI snapshots

This directory is where the official Zhipu/GLM specs are stored locally.

Run:

```bash
npm run download:openapi
```

Expected outputs:

- `zhipu-openapi.json`
- `zhipu-asyncapi.json`
- `download-metadata.json`

The official URLs are recorded in `spec-sources.json`.
