import { createZhipuClient } from '../src/index.js';

const zhipu = createZhipuClient();

const response = await zhipu.chatCompletions({
  model: 'glm-5.2',
  messages: [
    { role: 'system', content: '你是一个有用的 AI 助手。' },
    { role: 'user', content: '你好，简单介绍一下自己。' },
  ],
  temperature: 0.6,
  stream: false,
});

console.log(JSON.stringify(response, null, 2));
