/**
 * Run `npm run refresh` first.
 *
 * Then inspect ./src/generated for the generated operation names derived from
 * Zhipu's official OpenAPI operationId values. Hey API also generates a shared
 * `client` instance you can configure manually if needed.
 */
import { client } from '../src/generated/client.gen.js';

function env(name: string): string | undefined {
  return (globalThis as unknown as { process?: { env?: Record<string, string | undefined> } })
    .process?.env?.[name];
}

const apiKey = env('ZHIPU_API_KEY');

client.setConfig({
  baseUrl: env('ZHIPU_BASE_URL') ?? 'https://open.bigmodel.cn/api/paas/v4',
  headers: apiKey ? { Authorization: `Bearer ${apiKey}` } : undefined,
});

console.log('Generated client configured. Import generated operation helpers from ./src/generated.');
