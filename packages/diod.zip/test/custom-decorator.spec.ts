// tests/custom-decorator.spec.ts
import 'reflect-metadata'
import { describe, it, expect } from 'bun:test'
import { ContainerBuilder } from '../src'
import { OtherServiceWithCustomDecorator } from './fixtures/other-service-with-custom-decorator'
import { ServiceWithCustomDecorator } from './fixtures/service-with-custom-decorator'
import { Truer } from './fixtures/truer'
import { expectOk, expectExist } from './_helpers'

describe('user defined decorators can be used', () => {
	it('registers via custom decorator and resolves dependency', () => {
		// Arrange
		const builder = new ContainerBuilder()
		expectOk(builder.registerAndUse(ServiceWithCustomDecorator))
		expectOk(builder.register(Truer)).use(OtherServiceWithCustomDecorator)
		const container = expectOk(builder.build())

		// Act
		const service = expectExist(container.get(ServiceWithCustomDecorator))

		// Assert
		expect(service.constructor.name).toBe('ServiceWithCustomDecorator')
		expect(service.execDep()).toBeTrue()
	})
})
